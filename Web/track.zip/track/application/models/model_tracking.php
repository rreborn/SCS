<?php
class model_tracking extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	var $tabel = 'tracking';
	
	public function get_max_id($idspj)
	{
		$this->db->select('max(idtracking) as id');
		$this->db->from($this->tabel);
		$this->db->where('idspj',$idspj);
		$query = $this->db->get();
		return $query->row()->id;
	}
	public function get_position($idspj)
	{
		$idtracking=$this->get_max_id($idspj);
		$this->db->select('latitude,longitude');
		$this->db->from($this->tabel);
		$this->db->where('idtracking',$idtracking);
		$query = $this->db->get();
		return $query->row_array();	
	}
	public function set_tracking($data)
	{
		$this->db->insert($this->tabel,$data);
	}
	
}
?>