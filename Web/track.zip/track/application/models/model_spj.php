<?php
class model_spj extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	var $tabel = 'spj';
	
	public function set_spj($data){				
		$this->db->set('nspj', $nspj);
		$this->db->set('tanggal_buat', $tanggal_buat);
		$this->db->set('idtruk', $idtruk);
		$this->db->set('iduser_supir', $idtruk);
		$this->db->set('iduser_supervisor', $idtruk);
		$this->db->set('idstasiun_asal', $idtruk);
		$this->db->set('idstasiun_tujuan', $idtruk);
		$this->db->insert($this->tabel);				
	}
	
	public function update_spj($idspj,$data){
		$this->db->where('idspj', $idspj); //UBAH SESUAI PRIMARY KEY PADA TABEL
		$this->db->set('nspj', $nspj);
		$this->db->set('tanggal_buat', $tanggal_buat);
		$this->db->set('idtruk', $idtruk);
		$this->db->set('iduser_supir', $idtruk);
		$this->db->set('iduser_supervisor', $idtruk);
		$this->db->set('idstasiun_asal', $idtruk);
		$this->db->set('idstasiun_tujuan', $idtruk);
		$this->db->update($this->tabel);
//		$this->db->update($this->tabel,$data);
		return TRUE;
	}
	
	public function delete_spj($idspj){
		$this->db->where('idspj', $idspj); //UBAH SESUAI PRIMARY KEY PADA TABEL
		$this->db->delete($this->tabel);
	}
	
	public function get_spj($idspj){				
		$this->db->select('idspj,nspj,idsupir');
		$this->db->from($this->tabel);
		$this->db->where('idspj',$idspj);
		$query = $this->db->get();
		return $query->row_array();	
	}
	
	public function get_all_spj(){				
		$this->db->select('idspj,nspj,waktu_berangkat,waktu_kembali,idtruk,iduser_supir,idstasiun_asal,idstasiun_tujuan');
		$this->db->from($this->tabel);
		$query = $this->db->get();
		return $query->result_array();	
	}
}
?>