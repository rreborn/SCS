<?php
class model_user extends CI_Model{	
	
	public function __construct() {
		parent::__construct();		
		$this->load->database(); 
	}
	
	var $tabel = 'user';  //UBAH NAMA TABEL UTAMA
	
	public function set_user($data){				
		$this->db->insert($this->tabel,$data);				
	}
	
	public function update_user($user_id,$data){
		$this->db->where('iduser', $user_id); //UBAH SESUAI PRIMARY KEY PADA TABEL
		$this->db->update($this->tabel,$data);
		return TRUE;
	}
	
	public function delete_user($user_id){
		$this->db->where('iduser', $user_id); //UBAH SESUAI PRIMARY KEY PADA TABEL
		$this->db->delete($this->tabel);
	}
	
	public function get_user($user_id){				
		$this->db->select('*');
		$this->db->from($this->tabel);
		$this->db->where('iduser',$user_id);
		$query = $this->db->get();
		return $query->row_array();	
	}
	
	public function get_all_user(){				
		$this->db->select('iduser,nama,idakses');
		$this->db->from($this->tabel);
		$query = $this->db->get();
		return $query->result_array();	
	}
}
?>