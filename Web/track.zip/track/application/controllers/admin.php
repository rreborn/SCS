<?php
class admin extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('array');
//		$this->load->database();
	}

	public function index(){
		$this->load->view('view_admin');	
	}
	
	public function login(){
		$this->load->view('view_login');	
	}

	public function new_user($action,$id){
		$data['iduser']=$id;
		$data['nama']='';
		$data['email']='';
		$data['username']='';
		$data['idakses']=0;
		$data['action']=$action;
		if($action=='new'){
			$this->load->view('view_admin_new_user',$data);	
		}
		else{
			$data=$this->find_user($id);
			$data['action']=$action;
			$this->load->view('view_admin_new_user',$data);	
		}
	}
	
	public function manage_user(){
		$data['action']='edit';
		$data['users']=$this->find_all_user();
		$this->load->view('view_admin_edit_user',$data);	
	}
	
	public function create_user($id){
		$this->load->model('model_user');
		$action=$this->input->post('action');
		$data = array(
			'nama'  	=> $this->input->post('nama'),
			'email'  	=> $this->input->post('email'),
			'username'	=> $this->input->post('username'),
			'password'	=> md5($this->input->post('password')),
			'status'		=> 1,
			'idakses'		=> $this->input->post('role')
		);
		if($action=='new')
		{
			$this->model_user->set_user($data);
			redirect('admin/new_user/new/0');
		}
		else
		{
			if($this->model_user->update_user($id,$data))
				redirect('admin/manage_user/');
			else
				echo $id;
		}
	}
	
	public function test(){
		echo date('Y-m-d H:i:s',strtotime('+6 hours'));
	}

	
	public function delete_user($id){
		$this->load->model('model_user');
		$this->model_user->delete_user($id);
		redirect('admin/manage_user/');
	}
	
	public function find_user($id){
		$this->load->model('model_user');
		return $this->model_user->get_user($id);
	}
	
	public function find_all_user(){
		$this->load->model('model_user');
		return $this->model_user->get_all_user();
	}
	public function new_sop($action,$id){
		if($action=='new'){
			$data['idartikel']=$id;
			$data['judul']='';
			$data['isi']='';
			$data['keterangan']='';
			$data['idjenis_artikel']=0;	
		}
		else{
			$data=$this->find_sop($id);
		}
		$data['action']=$action;
		$this->load->view('view_admin_new_sop',$data);	
	}
	
	public function manage_sop(){
		$data['action']='edit';
		$data['sops']=$this->find_all_sop();
		$this->load->view('view_admin_edit_sop',$data);	
	}
	
	public function create_sop($id){
		$this->load->model('model_sop');
		$action=$this->input->post('action');
		$data = array(
			'judul'  			=> $this->input->post('judul'),
			'isi'  				=> $this->input->post('isi'),
			'tanggal_buat'		=> date('Y-m-d H:i:s',strtotime('+6 hours')),
			'status'			=> 1,
			'keterangan'		=> $this->input->post('keterangan'),
			'iduser'			=> 1,
			'idjenis_artikel'	=> $this->input->post('jenis')
		);
		if($action=='new')
		{
			$this->model_sop->set_sop($data);
			redirect('admin/new_sop/new/0');
		}
		else
		{
			if($this->model_sop->update_sop($id,$data))
				redirect('admin/manage_sop/');
			else
				echo $id;
		}
	}
	
	public function delete_sop($id){
		$this->load->model('model_sop');
		$this->model_sop->delete_sop($id);
		redirect('admin/manage_sop/');
	}
	
	public function find_sop($id){
		$this->load->model('model_sop');
		return $this->model_sop->get_sop($id);
	}
	
	public function find_all_sop(){
		$this->load->model('model_sop');
		return $this->model_sop->get_all_sop();
	}
	
}
?>