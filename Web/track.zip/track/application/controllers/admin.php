<?php
class admin extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
//		$this->load->model('model_admin');
//		$this->load->database();
	}

	public function index(){
		$this->load->view('view_admin');	
	}

	public function new_user(){
		$this->load->view('view_admin_new_user');	
	}
	
	public function manage_user(){
		$this->load->view('view_admin_edit_user');	
	}
	
	public function set_user(){
	
	}
	
	public function get_user(){
	
	}
	
	public function edit_user(){
	
	}
	
	public function delete_user(){

	}
	
	public function new_sop(){
		$this->load->view('view_admin_new_sop');	
	}
	
	public function manage_sop(){
		$this->load->view('view_admin_edit_sop');	
	}
	
	public function set_sop(){
	
	}
	
	public function get_sop(){
	
	}
	
	public function edit_sop(){
	
	}
	
	public function delete_sop(){

	}
}
?>