<?php
class supervisor extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('array');
	}
	public function test()
	{
		$this->load->model('model_tracking');
		$ids=array(1,2);
		$poss=$this->model_tracking->get_position_all($ids);
		foreach ($poss as $pos)
			echo $pos['latitude'].','.$pos['longitude'];
	}
	public function index(){
		$this->load->library('googlemaps');
		$this->load->model('model_tracking');

	//	$config['center'] = '7.2853, 112.7525';
		$config['zoom'] = 'auto';
		$this->googlemaps->initialize($config);
		
		
		if(!($this->input->post('spj'))){
			$ids=array(1,2);
			$poss=$this->model_tracking->get_position_all($ids);
			foreach($poss as $pos){
				if($pos){
					$marker = array();
					$marker['position'] = $pos['latitude'].', '.$pos['longitude'];
					$marker['draggable'] = true;
				//	$marker['ondragend'] = 'updateDatabase(event.latLng.lat(), event.latLng.lng());';
					$this->googlemaps->add_marker($marker);
				}
			}
			$data['idspj']=0;
		}
		else{
			$pos=$this->model_tracking->get_position($this->input->post('spj'));
			if($pos){
				$marker = array();
				$marker['position'] = $pos['latitude'].', '.$pos['longitude'];
				$marker['draggable'] = true;
			//	$marker['ondragend'] = 'updateDatabase(event.latLng.lat(), event.latLng.lng());';
				$this->googlemaps->add_marker($marker);
			}
			$data['idspj']=$this->input->post('spj');
		}
		
		$data['map']=$this->googlemaps->create_map();

		$this->load->view('view_supervisor_maps',$data);
	
	}
	public function track_id($idspj){
		echo $idspj;
	}

	public function new_spj($action,$id){
		$data['idspj']=$id;
		$data['nspj']='';
		$data['waktu_berangkat']='';
		$data['waktu_kembali']='';
		$data['idtruk']=0;
		$data['iduser_supir']=0;
		$data['idstasiun_asal']=0;
		$data['idstasiun_tujuan']=0;
		$data['action']=$action;
		if($action=='new'){
			$this->load->view('view_supervisor_new_spj',$data);	
		}
		else{
			$data=$this->find_spj($id);
			$data['action']=$action;
			$this->load->view('view_supervisor_new_spj',$data);	
		}
	}

	public function manage_spj(){
		$data['action']='edit';
		$data['spjs']=$this->find_all_spj();
		$this->load->view('view_supervisor_edit_spj',$data);	
	}
	
	public function create_spj($id){
		$this->load->model('model_spj');
		$action=$this->input->post('action');
		$data = array(
			'nspj'  			=> $this->input->post('nspj'),
			'tanggal_buat'  	=> date('Y-m-d H:i:s',strtotime('+6 hours')),
			'idtruk'  			=> ('t$this->input->postruk'),
			'iduser_supir'		=> $this->input->post('supir'),
			'iduser_supervisor'	=> 2,
			'idstasiun_asal'	=> $this->input->post('asal'),
			'idstasiun_tujuan'	=> $this->input->post('tujuan')
		);
		if($action=='new')
		{
			$this->model_spj->set_spj($data);
			redirect('supervisor/new_spj/new/0');
		}
		else
		{
			if($this->model_spj->update_spj($id,$data))
				redirect('supervisor/manage_spj/');
			else
				echo $id;
		}
	}
	
	public function delete_spj($id){
		$this->load->model('model_spj');
		$this->model_spj->delete_spj($id);
		redirect('supervisor/manage_spj/');
	}
	
	public function find_spj($id){
		$this->load->model('model_spj');
		return $this->model_spj->get_spj($id);
	}
	
	public function find_all_spj(){
		$this->load->model('model_spj');
		return $this->model_spj->get_all_spj();
	}
	
	public function tracking(){
		
		$this->load->model('model_tracking');
		
		$data = array(
			'longitude' => $_POST["longitude"],	
			'latitude' => $_POST["latitude"],
			'idspj' => $_POST["idspj"]
		);
		
		$this->model_tracking->set_tracking($data);			
	}
	
}
?>