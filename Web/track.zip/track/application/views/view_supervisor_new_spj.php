<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin | Dashboard</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="<?php echo base_url(); ?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="<?php echo base_url(); ?>css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
        <link href="<?php echo base_url(); ?>css/morris/morris.css" rel="stylesheet" type="text/css" />
        <!-- jvectormap -->
        <link href="<?php echo base_url(); ?>css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <!-- fullCalendar -->
        <link href="<?php echo base_url(); ?>css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
        <!-- Daterange picker -->
        <link href="<?php echo base_url(); ?>css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="<?php echo base_url(); ?>css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="<?php echo base_url(); ?>css/AdminLTE.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
            <a href="<?php echo base_url(); ?>admin/" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                Admin
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user"></i>
                                <span>Jane Doe <i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header bg-light-blue">
                                    <img src="img/avatar3.png" class="img-circle" alt="User Image" />
                                    <p>
                                        Jane Doe - Web Developer
                                        <small>Member since Nov. 2012</small>
                                    </p>
                                </li>
                                <!-- Menu Body -->
                                <li class="user-body">
                                    <div class="col-xs-4 text-center">
                                        <a href="#">Followers</a>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                        <a href="#">Sales</a>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                        <a href="#">Friends</a>
                                    </div>
                                </li>
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-left">
                                        <a href="#" class="btn btn-default btn-flat">Profile</a>
                                    </div>
                                    <div class="pull-right">
                                        <a href="#" class="btn btn-default btn-flat">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="img/avatar3.png" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, Admin</p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                    <!-- search form -->
                    <form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Search..."/>
                            <span class="input-group-btn">
                                <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-laptop"></i>
                                <span>Accounts</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?php echo base_url(); ?>admin/new_user/new/0"><i class="fa fa-angle-double-right"></i>Add New Account</a></li>
                                <li><a href="<?php echo base_url(); ?>admin/manage_user"><i class="fa fa-angle-double-right"></i>Manage Account</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-edit"></i> <span>SOP(s)</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="<?php echo base_url(); ?>admin/new_sop/new/0"><i class="fa fa-angle-double-right"></i>Add New SOP</a></li>
                                <li><a href="<?php echo base_url(); ?>admin/manage_sop"><i class="fa fa-angle-double-right"></i>Manage SOP</a></li>
                            </ul>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Home
                        <small>Administrator</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><i class="fa fa-dashboard"></i> Home</li>
                        <li class="active"></li>
                    </ol>
                </section>
				
                <!-- Main content -->
				<br/>
				<form name="supervisor_new_spj" action="<?php echo base_url() ?>supervisor/create_spj/<?php echo $idspj; ?>" method="post">
					<input name="action" type="hidden" id="action" value="<?php echo $action; ?>" readonly />
					<input name="idspj" type="hidden" id="idspj" value="<?php echo $idspj; ?>" readonly />					<div class="col-md-12">
						<button class="btn btn-default" type="submit">
							Save
						</button>
					</div>
					<br/><br/>
					<div class="col-md-12">
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="judul">NSPJ</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<input name="nspj" type="text" id="nspj" required class="form-control col-md-6 col-xs-12" value="<?php echo $nspj; ?>" />
							</div>
						</div>
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="waktu_berangkat">Waktu Berangkat</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<input name="waktu_berangkat" type="text" id="waktu_berangkat" class="form-control col-md-6 col-xs-12" value="<?php echo $waktu_berangkat; ?>" readonly />
							</div>
						</div>
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="waktu_kembali">Waktu Kembali</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<input name="waktu_kembali" type="text" id="waktu_kembali" class="form-control col-md-6 col-xs-12" value="<?php echo $waktu_kembali; ?>" readonly />
							</div>
						</div>
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="truk">Truk</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<select name="truk" class="form-control" id="truk" value="as" onchange="">
									<option <?php if($idtruk==0){echo "selected";} ?> disabled></option>
									<option value=1 <?php if($idtruk==1){echo "selected";} ?> >SOP</option>
									<option value=2 <?php if($idtruk==2){echo "selected";} ?> >Bukan SOP</option>
								</select>
							</div>
						</div>
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="supir">Supir</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<select name="supir" class="form-control" id="supir" value="as" onchange="">
									<option <?php if($iduser_supir==0){echo "selected";} ?> disabled></option>
									<option value=1 <?php if($iduser_supir==1){echo "selected";} ?> >SOP</option>
									<option value=2 <?php if($iduser_supir==2){echo "selected";} ?> >Bukan SOP</option>
								</select>
							</div>
						</div>
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="asal">Stasiun Asal</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<select name="asal" class="form-control" id="asal" value="as" onchange="">
									<option <?php if($idstasiun_asal==0){echo "selected";} ?> disabled></option>
									<option value=1 <?php if($idstasiun_asal==1){echo "selected";} ?> >SOP</option>
									<option value=2 <?php if($idstasiun_asal==2){echo "selected";} ?> >Bukan SOP</option>
								</select>
							</div>
						</div>
						<div class="form-group col-md-12">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="tujuan">Stasiun Tujuan</label>
							<div class="col-md-9 col-sm-9 col-xs-12">
								<select name="tujuan" class="form-control" id="tujuan" value="as" onchange="">
									<option <?php if($idstasiun_tujuan==0){echo "selected";} ?> disabled></option>
									<option value=1 <?php if($idstasiun_tujuan==1){echo "selected";} ?> >SOP</option>
									<option value=2 <?php if($idstasiun_tujuan==2){echo "selected";} ?> >Bukan SOP</option>
								</select>
							</div>
						</div>
					</div>	
				</form>
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

        <!-- add new calendar event modal -->

		<!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="<?php echo base_url(); ?>js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="<?php echo base_url(); ?>js/bootstrap.min.js" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="<?php echo base_url(); ?>js/plugins/morris/morris.min.js" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="<?php echo base_url(); ?>js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- jvectormap -->
        <script src="<?php echo base_url(); ?>js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <!-- fullCalendar -->
        <script src="<?php echo base_url(); ?>js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
        <!-- jQuery Knob Chart -->
        <script src="<?php echo base_url(); ?>js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="<?php echo base_url(); ?>js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="<?php echo base_url(); ?>js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <!-- iCheck -->
        <script src="<?php echo base_url(); ?>js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

        <!-- AdminLTE App -->
        <script src="<?php echo base_url(); ?>js/AdminLTE/app.js" type="text/javascript"></script>
        
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="<?php echo base_url(); ?>js/AdminLTE/dashboard.js" type="text/javascript"></script>     
        
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url(); ?>js/AdminLTE/demo.js" type="text/javascript"></script>

    </body>
</html>