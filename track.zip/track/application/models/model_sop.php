<?php
class model_sop extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	var $tabel = 'artikel';
	
	public function set_sop($data){				
		$this->db->insert($this->tabel,$data);				
	}
	
	public function update_sop($idartikel,$data){
		$this->db->where('idartikel', $idartikel); //UBAH SESUAI PRIMARY KEY PADA TABEL
		$this->db->update($this->tabel,$data);
		return TRUE;
	}
	
	public function delete_sop($idartikel){
		$this->db->where('idartikel', $idartikel); //UBAH SESUAI PRIMARY KEY PADA TABEL
		$this->db->delete($this->tabel);
	}
	
	public function get_sop($idartikel){				
		$this->db->select('*');
		$this->db->from($this->tabel);
		$this->db->where('idartikel',$idartikel);
		$query = $this->db->get();
		return $query->row_array();	
	}
	
	public function get_all_sop(){				
		$this->db->select('idartikel,judul,idjenis_artikel');
		$this->db->from($this->tabel);
		$query = $this->db->get();
		return $query->result_array();	
	}
}
?>